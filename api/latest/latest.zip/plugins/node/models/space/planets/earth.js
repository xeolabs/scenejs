/**
 * Planet earth model
 *
 * @author xeolabs / http://xeolabs.com
 *
 * <p>Usage example:</p>
 *
 * <pre>
 * someNode.addNode({
 *      type: "models/space/planets/earth"
 *  });
 * </pre>
 */
SceneJS.Types.addType("models/space/planets/earth", {

    construct: function (params) {

        var texturePath = SceneJS.getConfigs("pluginPath") + "/node/models/space/planets/earth/";

        var earthCloudsShadowTextureId = this.getId() + ".cloudsShadow";

        var node = this.addNode({
            type: "rotate",
            z: 1,
            angle: 195
        });

        var earthRotate = node = node.addNode({
            type: "rotate",
            y: 1
        });

        // Layer 0: Earth's surface with color, specular
        // and emissive maps

        node = node.addNode({
            type: "layer",
            priority: 0,

            nodes: [
                {
                    type: "scale",
                    x: 2,
                    y: 2,
                    z: 2,

                    nodes: [
                        {
                            type: "material",
                            emit: 1,
                            color: { r: 1.0, g: 1.0, b: 1.0 },
                            specularColor: { r: 0.6, g: 0.6, b: 0.6 },
                            specular: 1.0,
                            shine: 7.0,

                            nodes: [

                                // Color map
                                {
                                    type: "texture",
                                    coreId: this.type + ".color",
                                    src: texturePath + "earth.jpg",
                                    applyTo: "color",

                                    nodes: [
                                        {
                                            type: "texture",
                                            id: earthCloudsShadowTextureId,
                                            src: texturePath + "earthcloudsShadow.jpg",
                                            applyTo: "color",
                                            flipY: false,
                                            blendMode: "multiply",
                                            blendFactor: 0.5,
                                            translate: {
                                                x: 0
                                            },

                                            // Sphere with some material
                                            nodes: [

                                                // Normal map
                                                {
                                                    type: "texture",
                                                    coreId: this.type + ".normal",
                                                    src: texturePath + "bumpearthTexture.jpg",
                                                    applyTo: "normals",

                                                    nodes: [

                                                        // Specular map for shiny oceans
                                                        {
                                                            type: "texture",
                                                            coreId: this.type + ".specular",
                                                            src: texturePath + "earth-specular.png",
                                                            applyTo: "specular",

                                                            nodes: [

                                                                // Glow map for lights on night side
                                                                {
                                                                    type: "texture",
                                                                    coreId: this.type + ".emit",
                                                                    src: texturePath + "earth-lights.gif",
                                                                    applyTo: "emit",

                                                                    nodes: [

                                                                        // Sphere geometry
                                                                        {
                                                                            type: "geometry/sphere",
                                                                            latitudeBands: 120,
                                                                            longitudeBands: 120
                                                                        }
                                                                    ]
                                                                }
                                                            ]
                                                        }
                                                    ]
                                                }
                                            ]
                                        }
                                    ]
                                }
                            ]
                        }
                    ]
                }
            ]
        });

        // Layer 1: Cloud layer with alpha map

        var cloudsRotate = node.addNode({
            type: "rotate",
            y: 1,
            nodes: [
                {
                    type: "layer",
                    priority: 1,
                    nodes: [
                        {
                            type: "flags",
                            flags: {
                                enabled: true,
                                transparent: true,
                                specular: true,
                                diffuse: true,
                                ambient: true,
                                backfaces: false
                            },
                            nodes: [
                                {
                                    type: "material",
                                    emit: 0.01,
                                    alpha: 0.5,
                                    color: { r: 1, g: 1, b: 1 },
                                    specularColor: { r: 1.0, g: 1.0, b: 1.0 },
                                    specular: 1.0,
                                    shine: 1.0,

                                    nodes: [
                                        {
                                            type: "scale",
                                            x: 2.03,
                                            y: 2.03,
                                            z: 2.03,

                                            nodes: [
                                                {
                                                    type: "texture",
                                                    coreId: this.type + ".alpha",
                                                    src: texturePath + "earthclouds.jpg",
                                                    applyTo: "alpha",
                                                    flipY: false,

                                                    // Sphere with some material
                                                    nodes: [
                                                        {
                                                            type: "node",
                                                            z: 1,
                                                            angle: 195,

                                                            nodes: [
                                                                {
                                                                    type: "geometry/sphere",
                                                                    latitudeBands: 120,
                                                                    longitudeBands: 120
                                                                }
                                                            ]
                                                        }
                                                    ]
                                                }
                                            ]
                                        }
                                    ]
                                }
                            ]
                        }
                    ]
                }
            ]
        });

        node.addNode({
            type: "layer",
            priority: 2,

            nodes: [

                // X-Ray effect,
                // implemented by plugin at http://scenejs.org/api/latest/plugins/node/postprocess/xray.js
                {
                    type: "shader/xray",
                    id: "myXRay",

                    nodes: [
                        {
                            type: "material",
                            color:{ r:0.3, g:0.3, b:1.0 },
                            specular: 0.0,

                            nodes: [
                                {
                                    type: "scale",
                                    x: 2.05,
                                    y: 2.05,
                                    z: 2.05,

                                    nodes: [
                                        {
                                            type: "geometry/sphere",
                                            latitudeBands: 120,
                                            longitudeBands: 120
                                        }
                                    ]
                                }
                            ]
                        }
                    ]
                }
            ]
        });


        var earthAngle = 0;
        var cloudsAngle = 0;

        var cloudsShadow;
        this.getScene().getNode(earthCloudsShadowTextureId, function (c) {
            cloudsShadow = c;

        });

        var x = 0;

        this._tick = this.getScene().on("tick",
            function () {
                earthRotate.setAngle(earthAngle);
                cloudsRotate.setAngle(cloudsAngle);

                earthAngle -= 0.013;
                cloudsAngle -= 0.006;

                if (cloudsShadow) {
                    cloudsShadow.setTranslate({ x: x });
                }

                x -= 0.000025;
            });
    },

    // Node destructor, unsubscribes from scene tick
    destruct: function () {
        this.getScene().off(this._tick);
    }
});
