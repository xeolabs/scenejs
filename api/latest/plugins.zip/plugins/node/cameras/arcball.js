/**
 * Orbiting camera node type
 *
 * @author xeolabs / http://xeolabs.com
 *
 * <p>Usage</p>
 * <pre>
 * someNode.addNode({
 *      type: "cameras/arcball",
 *      eye:{ x: y:0 },
 *      look:{ y:0 },
 *      zoom: 350,
 *      zoomSensitivity:10.0,
 * });
 * </pre>
 * <p>The camera is initially positioned at the given 'eye' and 'look', then the distance of 'eye' is zoomed out
 * away from 'look' by the amount given in 'zoom', and then 'eye' is rotated by 'yaw' and 'pitch'.</p>
 *
 */
SceneJS.Types.addType("cameras/arcball", {

    construct: function (params) {

        var self = this;

        this._rotateSensitivity = params.rotateSensitivity || 0.1;

        this._zoom = params.zoom || 1.0;
        this._zoomSensitivity = params.zoomSensitivity || 1.0;
        this._zoomRange = params.zoomRange; // Can be undefined, then lazy-calculated in _update

        this._pan = params.pan || [0, 0, 0];

        this._q = null;
        this._mat = SceneJS_math_identityMat4();
        this._mat = SceneJS_math_inverseMat4(this._mat, []);

        this._lookat = this.addNode({
            type: "lookAt",
            eye: params.eye,
            look: params.look,
            up: params.up,
            nodes: params.nodes
        });

        this._orbit = params.orbit !== false;

        this._downPos = null;

        var dragging = false;

        var canvas = this.getScene().getCanvas();
        var width = canvas.width;
        var height = canvas.height;
        var center = [width / 2.0, height / 2.0];
        var radius = 0.9 * Math.min(width / 2, height / 2);

        canvas.addEventListener('mousedown', mouseDown, true);
        canvas.addEventListener('mousemove', mouseMove, true);
        canvas.addEventListener('mouseup', mouseUp, true);
        canvas.addEventListener('touchstart', touchStart, true);
        canvas.addEventListener('touchmove', touchMove, true);
        canvas.addEventListener('touchend', touchEnd, true);
        canvas.addEventListener('mousewheel', mouseWheel, true);
        canvas.addEventListener('DOMMouseScroll', mouseWheel, true);

        function mouseDown(event) {
            down(event.clientX, event.clientY);
        }

        function touchStart(event) {
            down(event.targetTouches[0].clientX, y = event.targetTouches[0].clientY);
        }

        function down(x, y) {
            self._downPos = screenToSphere(x, y);
            dragging = true;

            self._q = null; // Reset quaternion rotation
        }

        function mouseUp() {
            dragging = false;
        }

        function touchEnd() {
            dragging = false;
        }

        function mouseMove(event) {
            move(event.clientX, event.clientY);
        }

        function touchMove(event) {
            move(event.targetTouches[0].clientX, event.targetTouches[0].clientY);
        }

        function move(x, y) {
            if (dragging) {
                var pos = screenToSphere(x, y);
                var axis = SceneJS_math_cross3Vec3(self._downPos, pos, []);
                var angle = SceneJS_math_dotVector3(self._downPos, pos);
                self.addRotate([axis[0], axis[1], axis[2], angle]);
            }
        //    self._downPos = [pos[0], pos[1], pos[2]];
        }

        function mouseWheel(event) {
            var delta = 0;
            if (!event) event = window.event;
            if (event.wheelDelta) {
                delta = event.wheelDelta / 120;
                if (window.opera) delta = -delta;
            } else if (event.detail) {
                delta = -event.detail / 3;
            }
            if (delta) {
                var deltaZoom = 0;
                if (delta < 0) {
                    deltaZoom = -self._zoomSensitivity;
                } else {
                    deltaZoom = self._zoomSensitivity;
                }
                self.addZoom(deltaZoom);
            }
            if (event.preventDefault) {
                event.preventDefault();
            }
            event.returnValue = false;
        }

        function screenToSphere(x, y) {

            var pos = [(x - center[0]) / (radius * 2), (y - center[1]) / (radius * 2), 0];
            pos[0] *= -1;
            pos[1] *= -1;
            pos[2] *= -1;
            var len2 = SceneJS_math_sqLenVec3(pos);
            if (len2 > 1) {
                pos = SceneJS_math_mulVec3Scalar(pos, 1 / Math.sqrt(len2), []);
            }
            else {
                pos[2] = Math.sqrt(1 - len2);
                pos = SceneJS_math_normalizeVec3(pos, []);
            }
            return pos;
        }

        this._update();
    },

    setOrbit: function (orbit) {
        this._orbit = orbit;
        this._update();
    },

    getOrbit: function () {
        return this._orbit
    },

    setLookat: function (params) {
        this._lookat.set(params); // Update scene
        this._q = null; // Reset quaternion rotation
        this._pan = [0, 0, 0];
        this._zoomRange = null;
        //this._update();
    },

    getLookat: function () {
        return {
            eye: this._lookat.getEye(),
            look: this._lookat.getLook(),
            up: this._lookat.getUp()
        };
    },

    dragRotate: function (deltaX, deltaY) {
        var rotations = [
            SceneJS_math_angleAxisQuaternion(0.0, 1.0, 0.0, -deltaX * this._rotateSensitivity), // Y-axis rotation
            SceneJS_math_angleAxisQuaternion(1.0, 0.0, 0.0, -deltaY * this._rotateSensitivity)
        ];
        this._update(rotations);
    },

    addRotate: function (rotate) {
        var rotations = [SceneJS_math_angleAxisQuaternion(rotate[0], rotate[1], rotate[2], rotate[3])];
        this._update(rotations);
    },

    setZoomRange: function (zoomRange) {
        this._zoomRange = zoomRange;
        this._update();
    },

    getZoomRange: function () {
        return this._zoomRange;
    },

    setZoom: function (zoom) {
        this._zoom = zoom < 0 ? 0 : (zoom > 1.0 ? 1.0 : zoom);
        this._update();
    },

    addZoom: function (zoom) {
        this.setZoom(this._zoom + zoom);
    },

    getZoom: function () {
        return this._zoom;
    },

    setPan: function (pan) {
        this._pan = pan;
        this._update();
    },

    addPan: function (pan) {
        this._update(null, pan);
    },

    getPan: function () {
        return this._pan;
    },

    _update: function (rotations, pan) {

        if (!this._q) {
            this._q = SceneJS_math_identityQuaternion();
            this._eye = this._objToArray(this._lookat.getEye());
            this._look = this._objToArray(this._lookat.getLook());
            this._up = this._objToArray(this._lookat.getUp());
        }

        if (!this._zoomRange) {
            // Set zoom range to distance between current eye and look
            var eyeLookVec = SceneJS_math_subVec3(this._eye, this._look, []);
            this._zoomRange = [0, Math.abs(SceneJS_math_lenVec3(eyeLookVec))];
        }

        if (rotations) {
            for (var i = 0, len = rotations.length; i < len; i++) {
                this._q = SceneJS_math_mulQuaternions(this._q, rotations[i], []);
            }
            this._mat = SceneJS_math_newMat4FromQuaternion(this._q);
        }

        var eye2;
        var look2;
        var up2;

        if (this._orbit) {

            var zoom = this._zoomRange[0] + (this._zoom * (this._zoomRange[1] - this._zoomRange[0]));

            eye2 = SceneJS_math_subVec3(this._eye, this._look, []);
            eye2 = SceneJS_math_transformVector3(this._mat, eye2, []);
            eye2 = SceneJS_math_normalizeVec3(eye2);
            eye2 = SceneJS_math_mulVec3Scalar(eye2, zoom);
            eye2 = SceneJS_math_addVec3(eye2, this._look, []);
            look2 = this._look;

        } else {

            look2 = SceneJS_math_subVec3(this._look, this._eye, []);
            look2 = SceneJS_math_transformVector3(this._mat, look2, []);
            look2 = SceneJS_math_addVec3(look2, this._eye, []);
            eye2 = this._eye;
        }

        if (pan) {
            pan = SceneJS_math_transformVector3(this._mat, pan, []);
            SceneJS_math_addVec3(this._pan, pan);
        }

        eye2 = SceneJS_math_addVec3(eye2, this._pan, []);
        look2 = SceneJS_math_addVec3(look2, this._pan, []);
        up2 = SceneJS_math_transformVector3(this._mat, this._up, []);

        this._lookat.setEye({x: eye2[0], y: eye2[1], z: eye2[2] });
        this._lookat.setLook({x: look2[0], y: look2[1], z: look2[2] });
        this._lookat.setUp({x: up2[0], y: up2[1], z: up2[2] });
    },

    _objToArray: function (v) {
        return [v.x, v.y, v.z];
    },

    _arrayToObj: function (v) {
        return { x: v[0], y: v[1], z: v[2] };
    },

    destruct: function () {
        //   this.getScene().off(this.tick);
        // TODO: remove mouse handlers
    }
});

