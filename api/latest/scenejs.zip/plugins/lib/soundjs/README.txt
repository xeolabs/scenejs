This directory contains a compressed version of the SoundJS library.

You can also gzip the file to further reduce its size (by about 75%). Many servers do this automatically.
